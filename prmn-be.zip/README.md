# Dokumentasi Rest Api v.1.0.0
## Postman <a href="https://www.postman.com/winter-meadow-246387/workspace/prmn/collection/30144947-e34f30b6-7504-4ff8-8cf1-9c00c2b09a97?action=share&creator=30144947&active-environment=30144947-3892dbe1-eba7-4615-a5e5-c505c1b7f21b">Open Postman</a>

### Note
- Create Folder dengan nama public  pada 1 level dengan src untuk menampung file hasil upload gambar pada form customer